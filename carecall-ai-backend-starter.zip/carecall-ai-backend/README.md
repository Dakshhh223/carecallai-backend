# CareCall AI Backend

This backend powers CareCall AI — a voice-only assistant for emotional and business support.

## Features
- Twilio call handling
- GPT-4 integration
- ElevenLabs voice response
- Modular structure

## Setup
```bash
pip install -r requirements.txt
cp .env.example .env
```
